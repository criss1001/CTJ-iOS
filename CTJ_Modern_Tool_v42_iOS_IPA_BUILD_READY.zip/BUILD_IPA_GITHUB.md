# Build IPA with GitHub Actions

This project includes `.github/workflows/build-ipa.yml`.
Upload the contents of this folder to a GitHub repository. The workflow builds the iPhoneOS Release target with code signing disabled and packages the resulting `.app` as `CTJ_Modern_Tool_v42-unsigned.ipa`.

The resulting IPA is unsigned and must be signed with your own Apple developer certificate/profile or a compatible sideloading signer before installation.
