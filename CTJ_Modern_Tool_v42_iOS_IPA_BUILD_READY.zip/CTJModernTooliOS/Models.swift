import Foundation
import SwiftUI
import UniformTypeIdentifiers

struct ShotRecord: Identifiable, Hashable {
    let id = UUID()
    var offset: Int
    var playerID: UInt8
    var shotSlot: UInt8
    var raw: [UInt8]
    var team: Int?
    var playerSlot: Int?
}

struct DataDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.data] }
    var data: Data
    init(data: Data) { self.data = data }
    init(configuration: ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}

@MainActor final class CTJModel: ObservableObject {
    @Published var teamData = Data()
    @Published var teamDataName = ""
    @Published var selectedTeam = 0
    @Published var selectedPlayer = 0
    @Published var captinData = Data()
    @Published var captinName = ""
    @Published var shots: [ShotRecord] = []
    @Published var status = "جاهز"
    @Published var discData = Data()
    @Published var discName = ""
    @Published var discFiles: [PSXDiscFile] = []
    @Published var selectedDiscPath = ""

    let teamCount = 0x2D

    func importTEAMDAT(url: URL) {
        do {
            let ok = url.startAccessingSecurityScopedResource(); defer { if ok { url.stopAccessingSecurityScopedResource() } }
            teamData = try Data(contentsOf: url)
            teamDataName = url.lastPathComponent
            selectedPlayer = 0
            status = "تم تحميل \(teamDataName) — \(teamData.count) bytes"
        } catch { status = "فشل فتح TEAMDAT: \(error.localizedDescription)" }
    }

    func playerRecord(_ index: Int) -> [UInt8] {
        let off = index * 16
        guard teamData.count >= off + 16 else { return Array(repeating: 0, count: 16) }
        return Array(teamData[off..<(off + 16)])
    }

    func savePlayer(_ index: Int, bytes: [UInt8]) {
        let off = index * 16
        guard bytes.count == 16, teamData.count >= off + 16 else { status = "ملف TEAMDAT لا يحتوي هذا السجل"; return }
        teamData.replaceSubrange(off..<(off + 16), with: bytes)
        status = "✅ تم حفظ Player \(index) داخل النسخة المعدلة"
    }

    func importCAPTIN(url: URL) {
        do {
            let ok = url.startAccessingSecurityScopedResource(); defer { if ok { url.stopAccessingSecurityScopedResource() } }
            captinData = try Data(contentsOf: url)
            captinName = url.lastPathComponent
            loadShotCSV()
            status = "تم تحميل \(captinName) — جاهز لتعديل التسديدات"
        } catch { status = "فشل فتح CAPTIN.EXE: \(error.localizedDescription)" }
    }

    func loadShotCSV() {
        guard let u = Bundle.main.url(forResource: "CTJ_CAPTIN_shot_records_mapped_by_team_slot", withExtension: "csv", subdirectory: "Data"),
              let txt = try? String(contentsOf: u, encoding: .utf8) else { shots = []; return }
        let rows = CSV.parse(txt)
        guard let header = rows.first else { return }
        func col(_ names: [String]) -> Int? { names.compactMap { n in header.firstIndex(where: { $0.lowercased() == n.lowercased() }) }.first }
        let oi = col(["offset"]), pi = col(["player_id","owner_id"]), si = col(["shot_slot","slot"])
        let ti = col(["team","team_id","team_hex"]), psi = col(["player_slot","team_slot"]), ri = col(["raw_hex","raw"])
        guard let o = oi, let p = pi, let s = si else { return }
        var out: [ShotRecord] = []
        for r in rows.dropFirst() where r.count > max(o,p,s) {
            let off = Int(r[o].replacingOccurrences(of: "0x", with: ""), radix: r[o].lowercased().contains("0x") ? 16 : 10) ?? Int(r[o]) ?? 0
            let pid = UInt8(r[p].replacingOccurrences(of: "0x", with: ""), radix: 16) ?? UInt8(r[p]) ?? 0
            let slot = UInt8(r[s].replacingOccurrences(of: "0x", with: ""), radix: 16) ?? UInt8(r[s]) ?? 0
            let raw = (ri != nil && r.count > ri!) ? Self.hexBytes(r[ri!]) : (captinData.count >= off+14 ? Array(captinData[off..<(off+14)]) : [])
            let team = ti.flatMap { i -> Int? in guard r.count > i else { return nil }; return Int(r[i].replacingOccurrences(of:"0x",with:""), radix:16) ?? Int(r[i]) }
            let ps = psi.flatMap { i -> Int? in guard r.count > i else { return nil }; return Int(r[i]) }
            out.append(ShotRecord(offset: off, playerID: pid, shotSlot: slot, raw: raw, team: team, playerSlot: ps))
        }
        shots = out
    }

    func patchShot(source: ShotRecord, target: ShotRecord, mode: ShotMode) {
        guard captinData.count >= target.offset + 14 else { status = "Offset خارج CAPTIN.EXE"; return }
        var src = source.raw.count >= 14 ? Array(source.raw.prefix(14)) : Array(repeating: 0, count: 14)
        if source.raw.count < 14, captinData.count >= source.offset + 14 { src = Array(captinData[source.offset..<(source.offset+14)]) }
        var dst = Array(captinData[target.offset..<(target.offset+14)])
        switch mode {
        case .copy, .duplicate:
            src[4] = target.playerID; src[5] = 0xFF; src[6] = 0xFF; src[10] = target.shotSlot
            captinData.replaceSubrange(target.offset..<(target.offset+14), with: src)
        case .swap:
            var toTarget = src
            toTarget[4] = target.playerID; toTarget[5] = 0xFF; toTarget[6] = 0xFF; toTarget[10] = target.shotSlot
            dst[4] = source.playerID; dst[5] = 0xFF; dst[6] = 0xFF; dst[10] = source.shotSlot
            captinData.replaceSubrange(target.offset..<(target.offset+14), with: toTarget)
            if captinData.count >= source.offset + 14 { captinData.replaceSubrange(source.offset..<(source.offset+14), with: dst) }
        case .delete:
            var cleared = dst
            cleared[4] = 0xFF; cleared[5] = 0xFF; cleared[6] = 0xFF
            captinData.replaceSubrange(target.offset..<(target.offset+14), with: cleared)
        }
        status = "✅ تم تطبيق \(mode.title) على CAPTIN.EXE المعدل"
    }

    static func hexBytes(_ s: String) -> [UInt8] {
        let clean = s.replacingOccurrences(of: "0x", with: "").replacingOccurrences(of: " ", with: "").replacingOccurrences(of: "-", with: "")
        var a:[UInt8]=[]; var i=clean.startIndex
        while clean.distance(from:i,to:clean.endIndex) >= 2 { let j=clean.index(i,offsetBy:2); if let b=UInt8(clean[i..<j],radix:16){a.append(b)}; i=j }
        return a
    }
}

enum ShotMode: String, CaseIterable { case copy, duplicate, swap, delete; var title:String { switch self { case .copy:return "نقل"; case .duplicate:return "Duplicate"; case .swap:return "Swap"; case .delete:return "Delete" } } }

enum CSV {
    static func parse(_ text:String)->[[String]] { text.split(whereSeparator:\.isNewline).map { line in
        var row:[String]=[]; var cur=""; var quoted=false; let cs=Array(line); var i=0
        while i<cs.count { let c=cs[i]; if c=="\"" { if quoted && i+1<cs.count && cs[i+1]=="\"" { cur.append("\""); i += 1 } else { quoted.toggle() } } else if c=="," && !quoted { row.append(cur); cur="" } else { cur.append(c) }; i += 1 }
        row.append(cur); return row
    } }
}

// MARK: - Native PS1 BIN/ISO support for iOS
// This replaces the Windows-only dumpsxiso/mkpsxiso path for CTJ edits that keep file sizes unchanged.

struct PSXDiscFile: Identifiable, Hashable {
    var id: String { path }
    let path: String
    let lba: Int
    let size: Int
    let isDirectory: Bool
    var name: String { path.split(separator: "/").last.map(String.init) ?? path }
}

enum PSXDiscError: LocalizedError {
    case unsupportedImage
    case invalidISO9660
    case fileNotFound
    case sizeChanged(expected: Int, got: Int)
    case unsupportedSector(Int)

    var errorDescription: String? {
        switch self {
        case .unsupportedImage: return "صيغة صورة القرص غير مدعومة. استخدم BIN خام 2352 أو ISO 2048."
        case .invalidISO9660: return "لم يتم العثور على ISO9660 صالح داخل صورة القرص."
        case .fileNotFound: return "الملف غير موجود داخل صورة القرص."
        case let .sizeChanged(expected, got): return "حجم الملف المعدل تغير (الأصلي \(expected)، الجديد \(got)). هذه الطريقة تتطلب نفس الحجم."
        case let .unsupportedSector(lba): return "Sector غير مدعوم عند LBA \(lba)."
        }
    }
}

struct PSXDiscImage {
    enum Layout { case iso2048, raw2352 }
    var data: Data
    let layout: Layout
    private(set) var files: [PSXDiscFile] = []

    init(data: Data) throws {
        self.data = data
        if data.count >= 17 * 2048,
           Self.hasPVD(in: data, offset: 16 * 2048) {
            layout = .iso2048
        } else if data.count >= 17 * 2352,
                  let off = Self.rawUserDataOffset(in: data, lba: 16),
                  Self.hasPVD(in: data, offset: 16 * 2352 + off) {
            layout = .raw2352
        } else {
            throw PSXDiscError.unsupportedImage
        }
        try scan()
    }

    private static func hasPVD(in data: Data, offset: Int) -> Bool {
        guard offset >= 0, offset + 7 <= data.count else { return false }
        return data[offset] == 1 && String(data: data[(offset+1)..<(offset+6)], encoding: .ascii) == "CD001"
    }

    private static func rawUserDataOffset(in data: Data, lba: Int) -> Int? {
        let base = lba * 2352
        guard base + 24 <= data.count else { return nil }
        let mode = data[base + 15]
        if mode == 1 { return 16 }
        if mode == 2 { return 24 }
        return nil
    }

    private func payload(lba: Int) throws -> Data {
        switch layout {
        case .iso2048:
            let base = lba * 2048
            guard base + 2048 <= data.count else { throw PSXDiscError.unsupportedSector(lba) }
            return data[base..<(base + 2048)]
        case .raw2352:
            let base = lba * 2352
            guard let off = Self.rawUserDataOffset(in: data, lba: lba), base + off + 2048 <= data.count else {
                throw PSXDiscError.unsupportedSector(lba)
            }
            return data[(base + off)..<(base + off + 2048)]
        }
    }

    private mutating func scan() throws {
        let pvd = try payload(lba: 16)
        guard pvd.count >= 190, pvd[0] == 1,
              String(data: pvd[1..<6], encoding: .ascii) == "CD001" else { throw PSXDiscError.invalidISO9660 }
        let root = try Self.parseDirectoryRecord(pvd, at: 156, parent: "")
        var out: [PSXDiscFile] = []
        var visited = Set<Int>()
        try walkDirectory(lba: root.lba, size: root.size, path: "", visited: &visited, output: &out)
        files = out.sorted { $0.path.localizedStandardCompare($1.path) == .orderedAscending }
    }

    private mutating func walkDirectory(lba: Int, size: Int, path: String, visited: inout Set<Int>, output: inout [PSXDiscFile]) throws {
        guard visited.insert(lba).inserted else { return }
        let dirData = try readExtent(lba: lba, size: size)
        var pos = 0
        while pos < dirData.count {
            let len = Int(dirData[pos])
            if len == 0 {
                pos = ((pos / 2048) + 1) * 2048
                continue
            }
            guard pos + len <= dirData.count else { break }
            if let rec = try? Self.parseDirectoryRecord(dirData, at: pos, parent: path) {
                let rawNameLength = Int(dirData[pos + 32])
                if rawNameLength == 1 {
                    let marker = dirData[pos + 33]
                    if marker == 0 || marker == 1 { pos += len; continue }
                }
                output.append(rec)
                if rec.isDirectory {
                    try walkDirectory(lba: rec.lba, size: rec.size, path: rec.path, visited: &visited, output: &output)
                }
            }
            pos += len
        }
    }

    private static func parseDirectoryRecord(_ bytes: Data, at pos: Int, parent: String) throws -> PSXDiscFile {
        guard pos + 34 <= bytes.count else { throw PSXDiscError.invalidISO9660 }
        let len = Int(bytes[pos])
        guard len >= 34, pos + len <= bytes.count else { throw PSXDiscError.invalidISO9660 }
        let lba = Int(le32(bytes, pos + 2))
        let size = Int(le32(bytes, pos + 10))
        let flags = bytes[pos + 25]
        let nameLen = Int(bytes[pos + 32])
        guard pos + 33 + nameLen <= bytes.count else { throw PSXDiscError.invalidISO9660 }
        var name = String(data: bytes[(pos+33)..<(pos+33+nameLen)], encoding: .ascii) ?? "?"
        if let semi = name.firstIndex(of: ";") { name = String(name[..<semi]) }
        let full = parent.isEmpty ? name : parent + "/" + name
        return PSXDiscFile(path: full, lba: lba, size: size, isDirectory: (flags & 0x02) != 0)
    }

    private static func le32(_ bytes: Data, _ p: Int) -> UInt32 {
        UInt32(bytes[p]) | (UInt32(bytes[p+1]) << 8) | (UInt32(bytes[p+2]) << 16) | (UInt32(bytes[p+3]) << 24)
    }

    func readFile(_ file: PSXDiscFile) throws -> Data {
        guard !file.isDirectory else { throw PSXDiscError.fileNotFound }
        return try readExtent(lba: file.lba, size: file.size)
    }

    private func readExtent(lba: Int, size: Int) throws -> Data {
        var out = Data(); out.reserveCapacity(size)
        let sectors = (size + 2047) / 2048
        for i in 0..<sectors { out.append(try payload(lba: lba + i)) }
        if out.count > size { out.removeSubrange(size..<out.count) }
        return out
    }

    mutating func replaceFile(_ file: PSXDiscFile, with replacement: Data) throws {
        guard replacement.count == file.size else { throw PSXDiscError.sizeChanged(expected: file.size, got: replacement.count) }
        var cursor = 0
        let sectors = (file.size + 2047) / 2048
        for i in 0..<sectors {
            let chunk = min(2048, file.size - cursor)
            let lba = file.lba + i
            switch layout {
            case .iso2048:
                let base = lba * 2048
                data.replaceSubrange(base..<(base + chunk), with: replacement[cursor..<(cursor + chunk)])
            case .raw2352:
                let base = lba * 2352
                guard let off = Self.rawUserDataOffset(in: data, lba: lba) else { throw PSXDiscError.unsupportedSector(lba) }
                data.replaceSubrange((base + off)..<(base + off + chunk), with: replacement[cursor..<(cursor + chunk)])
                try repairRawSector(lba: lba)
            }
            cursor += chunk
        }
    }

    // Recomputes EDC/ECC after modifying Mode 1 or Mode 2 Form 1 raw sectors.
    private mutating func repairRawSector(lba: Int) throws {
        let base = lba * 2352
        guard base + 2352 <= data.count else { throw PSXDiscError.unsupportedSector(lba) }
        let mode = data[base + 15]
        var sector = Array(data[base..<(base + 2352)])
        if mode == 1 {
            let edc = CDErrorCorrection.edc(Array(sector[0..<2064]))
            CDErrorCorrection.putLE32(edc, into: &sector, at: 2064)
            for i in 2068..<2076 { sector[i] = 0 }
            CDErrorCorrection.ecc(&sector, zeroAddressForMode2: false)
        } else if mode == 2 {
            // Bit 5 of the submode byte marks Form 2 (2324-byte payload); filesystem files are expected to be Form 1.
            if (sector[18] & 0x20) != 0 { throw PSXDiscError.unsupportedSector(lba) }
            let edc = CDErrorCorrection.edc(Array(sector[16..<2072]))
            CDErrorCorrection.putLE32(edc, into: &sector, at: 2072)
            CDErrorCorrection.ecc(&sector, zeroAddressForMode2: true)
        } else {
            throw PSXDiscError.unsupportedSector(lba)
        }
        data.replaceSubrange(base..<(base + 2352), with: sector)
    }
}

enum CDErrorCorrection {
    static let tables: ([UInt8], [UInt8], [UInt32]) = {
        var f = [UInt8](repeating: 0, count: 256)
        var b = [UInt8](repeating: 0, count: 256)
        var edc = [UInt32](repeating: 0, count: 256)
        for i in 0..<256 {
            var j = i << 1
            if (i & 0x80) != 0 { j ^= 0x11D }
            f[i] = UInt8(j & 0xFF)
            b[i ^ j] = UInt8(i)
            var v = UInt32(i)
            for _ in 0..<8 { v = (v >> 1) ^ ((v & 1) != 0 ? 0xD8018001 : 0) }
            edc[i] = v
        }
        return (f,b,edc)
    }()

    static func edc(_ bytes: [UInt8]) -> UInt32 {
        let table = tables.2
        var value: UInt32 = 0
        for byte in bytes { value = (value >> 8) ^ table[Int((value ^ UInt32(byte)) & 0xFF)] }
        return value
    }

    static func putLE32(_ value: UInt32, into bytes: inout [UInt8], at p: Int) {
        bytes[p] = UInt8(value & 0xFF); bytes[p+1] = UInt8((value >> 8) & 0xFF)
        bytes[p+2] = UInt8((value >> 16) & 0xFF); bytes[p+3] = UInt8((value >> 24) & 0xFF)
    }

    static func ecc(_ sector: inout [UInt8], zeroAddressForMode2: Bool) {
        let saved = Array(sector[12..<16])
        if zeroAddressForMode2 { for i in 12..<16 { sector[i] = 0 } }
        eccCompute(source: sector, sourceOffset: 12, majorCount: 86, minorCount: 24, majorMult: 2, minorInc: 86, destination: &sector, destinationOffset: 2076)
        eccCompute(source: sector, sourceOffset: 12, majorCount: 52, minorCount: 43, majorMult: 86, minorInc: 88, destination: &sector, destinationOffset: 2248)
        if zeroAddressForMode2 { for i in 0..<4 { sector[12+i] = saved[i] } }
    }

    static func eccCompute(source: [UInt8], sourceOffset: Int, majorCount: Int, minorCount: Int, majorMult: Int, minorInc: Int, destination: inout [UInt8], destinationOffset: Int) {
        let f = tables.0, b = tables.1
        let size = majorCount * minorCount
        for major in 0..<majorCount {
            var index = (major >> 1) * majorMult + (major & 1)
            var a: UInt8 = 0, bb: UInt8 = 0
            for _ in 0..<minorCount {
                let temp = source[sourceOffset + index]
                index += minorInc
                if index >= size { index -= size }
                a ^= temp; bb ^= temp; a = f[Int(a)]
            }
            a = b[Int(f[Int(a)] ^ bb)]
            destination[destinationOffset + major] = a
            destination[destinationOffset + major + majorCount] = a ^ bb
        }
    }
}

extension CTJModel {
    var discFileCount: Int { discFiles.filter { !$0.isDirectory }.count }

    func importDisc(url: URL) {
        do {
            let ok = url.startAccessingSecurityScopedResource(); defer { if ok { url.stopAccessingSecurityScopedResource() } }
            let d = try Data(contentsOf: url)
            let image = try PSXDiscImage(data: d)
            discData = image.data
            discName = url.lastPathComponent
            discFiles = image.files
            selectedDiscPath = image.files.first(where: { !$0.isDirectory && $0.name.uppercased() == "CAPTIN.EXE" })?.path ?? ""
            status = "✅ تم فتح القرص: \(discName) — \(discFileCount) ملف"
        } catch { status = "فشل فتح صورة القرص: \(error.localizedDescription)" }
    }

    func loadDiscFileIntoEditor(path: String) {
        do {
            var image = try PSXDiscImage(data: discData)
            guard let file = image.files.first(where: { $0.path == path && !$0.isDirectory }) else { throw PSXDiscError.fileNotFound }
            let bytes = try image.readFile(file)
            if file.name.uppercased() == "CAPTIN.EXE" {
                captinData = bytes; captinName = file.path; loadShotCSV()
                status = "✅ تم تحميل CAPTIN.EXE مباشرة من BIN"
            } else {
                teamData = bytes; teamDataName = file.path; selectedPlayer = 0
                status = "✅ تم تحميل \(file.name) من BIN إلى Player Editor"
            }
            selectedDiscPath = file.path
        } catch { status = "فشل استخراج الملف من القرص: \(error.localizedDescription)" }
    }

    func writeCurrentEditorFileBack(path: String) {
        do {
            var image = try PSXDiscImage(data: discData)
            guard let file = image.files.first(where: { $0.path == path && !$0.isDirectory }) else { throw PSXDiscError.fileNotFound }
            let replacement: Data
            if file.name.uppercased() == "CAPTIN.EXE" { replacement = captinData }
            else { replacement = teamData }
            try image.replaceFile(file, with: replacement)
            discData = image.data
            discFiles = image.files
            status = "✅ تم حقن \(file.name) داخل BIN وإصلاح EDC/ECC"
        } catch { status = "فشل الحقن داخل BIN: \(error.localizedDescription)" }
    }
}
