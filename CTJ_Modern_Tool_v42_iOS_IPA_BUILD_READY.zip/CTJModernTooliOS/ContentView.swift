import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject var model: CTJModel
    var body: some View {
        TabView {
            HomeView().tabItem { Label("الرئيسية", systemImage: "house.fill") }
            DiscToolsView().tabItem { Label("PS1 BIN", systemImage: "opticaldisc.fill") }
            PlayerEditorView().tabItem { Label("اللاعب", systemImage: "person.crop.rectangle") }
            ShotEditorView().tabItem { Label("التسديدات", systemImage: "soccerball") }
            TeamLogosView().tabItem { Label("الفرق", systemImage: "shield.lefthalf.filled") }
        }
        .tint(.cyan)
        .preferredColorScheme(.dark)
        .overlay(alignment: .top) { Text(model.status).font(.caption).padding(8).background(.ultraThinMaterial).clipShape(Capsule()).padding(.top, 4) }
    }
}

struct HomeView: View {
    @EnvironmentObject var model: CTJModel
    @State private var importTeam = false
    @State private var importCaptin = false
    @State private var exportTeam = false
    @State private var exportCaptin = false
    var body: some View {
        NavigationStack {
            ScrollView { VStack(spacing:16) {
                Image(systemName:"soccerball.circle.fill").font(.system(size:72)).foregroundStyle(.cyan)
                Text("Captain Tsubasa J").font(.largeTitle.bold())
                Text("Modern Tool v42 — iOS").foregroundStyle(.secondary)
                GroupBox("TEAMDAT / Player Stats") { VStack(spacing:10) {
                    Text(model.teamDataName.isEmpty ? "لم يتم اختيار ملف" : model.teamDataName).frame(maxWidth:.infinity,alignment:.leading)
                    Button("استيراد TEAMDAT") { importTeam=true }.buttonStyle(.borderedProminent)
                    Button("تصدير TEAMDAT المعدل") { exportTeam=true }.disabled(model.teamData.isEmpty)
                }.frame(maxWidth:.infinity) }
                GroupBox("CAPTIN.EXE / Shot Editor") { VStack(spacing:10) {
                    Text(model.captinName.isEmpty ? "لم يتم اختيار CAPTIN.EXE" : model.captinName).frame(maxWidth:.infinity,alignment:.leading)
                    Button("استيراد CAPTIN.EXE") { importCaptin=true }.buttonStyle(.borderedProminent)
                    Button("تصدير CAPTIN المعدل") { exportCaptin=true }.disabled(model.captinData.isEmpty)
                }.frame(maxWidth:.infinity) }
                GroupBox("PS1 Disc Tools — iOS Native") {
                    Text("افتح BIN من تبويب PS1 BIN. التطبيق يقرأ ISO9660 مباشرة ويحقن الملفات المعدلة في مكانها، ثم يصلح EDC/ECC للقطاعات الخام 2352. لا يحتاج dumpsxiso.exe أو mkpsxiso.exe لتعديلات CTJ ذات الحجم الثابت.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }.padding() }.navigationTitle("CTJ v42")
        }
        .fileImporter(isPresented:$importTeam, allowedContentTypes:[.data]) { if case .success(let u)=$0 { model.importTEAMDAT(url:u) } }
        .fileImporter(isPresented:$importCaptin, allowedContentTypes:[.data]) { if case .success(let u)=$0 { model.importCAPTIN(url:u) } }
        .fileExporter(isPresented:$exportTeam, document:DataDocument(data:model.teamData), contentType:.data, defaultFilename:"TEAMDAT_iOS_MOD.bin") {_ in}
        .fileExporter(isPresented:$exportCaptin, document:DataDocument(data:model.captinData), contentType:.data, defaultFilename:"CAPTIN_iOS_MOD.EXE") {_ in}
    }
}

struct DiscToolsView: View {
    @EnvironmentObject var model: CTJModel
    @State private var importDisc = false
    @State private var exportDisc = false
    @State private var search = ""

    var visibleFiles: [PSXDiscFile] {
        let all = model.discFiles.filter { !$0.isDirectory }
        if search.isEmpty { return all }
        return all.filter { $0.path.localizedCaseInsensitiveContains(search) }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                if model.discData.isEmpty {
                    ContentUnavailableView("افتح صورة لعبة PS1", systemImage: "opticaldisc", description: Text("يدعم BIN الخام 2352 وISO 2048"))
                    Button("اختيار BIN / ISO من Files") { importDisc = true }.buttonStyle(.borderedProminent)
                } else {
                    HStack {
                        VStack(alignment:.leading) {
                            Text(model.discName).font(.headline)
                            Text("\(model.discFileCount) ملف داخل القرص").font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button("تغيير القرص") { importDisc = true }.buttonStyle(.bordered)
                    }.padding(.horizontal)

                    List {
                        Section("ملفات CTJ") {
                            ForEach(visibleFiles) { file in
                                VStack(alignment:.leading, spacing:6) {
                                    HStack {
                                        VStack(alignment:.leading) {
                                            Text(file.path).font(.subheadline.monospaced())
                                            Text("LBA \(file.lba) • \(file.size) bytes").font(.caption2).foregroundStyle(.secondary)
                                        }
                                        Spacer()
                                    }
                                    HStack {
                                        Button("فتح في المحرر") { model.loadDiscFileIntoEditor(path: file.path) }.buttonStyle(.bordered)
                                        Button("حقن النسخة المعدلة") { model.writeCurrentEditorFileBack(path: file.path) }
                                            .buttonStyle(.borderedProminent)
                                            .disabled(file.name.uppercased() == "CAPTIN.EXE" ? model.captinData.isEmpty : model.teamData.isEmpty)
                                    }
                                }.padding(.vertical,3)
                            }
                        }
                    }.searchable(text:$search, prompt:"CAPTIN.EXE أو TEAMDAT")

                    Button("تصدير BIN المعدل") { exportDisc = true }
                        .buttonStyle(.borderedProminent).padding(.bottom,8)
                }
            }
            .navigationTitle("PS1 Disc Tools")
        }
        .fileImporter(isPresented:$importDisc, allowedContentTypes:[.data]) { if case .success(let u)=$0 { model.importDisc(url:u) } }
        .fileExporter(isPresented:$exportDisc, document:DataDocument(data:model.discData), contentType:.data, defaultFilename:patchedDiscName) {_ in}
    }

    var patchedDiscName: String {
        guard !model.discName.isEmpty else { return "CTJ_PATCHED.bin" }
        let ns = model.discName as NSString
        let ext = ns.pathExtension.isEmpty ? "bin" : ns.pathExtension
        return ns.deletingPathExtension + "_iOS_PATCHED." + ext
    }
}

struct PlayerEditorView: View {
    @EnvironmentObject var model: CTJModel
    @State private var bytes = Array(repeating:0, count:16)
    var body: some View { NavigationStack { Form {
        Section("اللاعب") {
            Stepper("Player Slot: \(model.selectedPlayer)", value:$model.selectedPlayer, in:0...63)
            Button("تحميل السجل") { bytes=model.playerRecord(model.selectedPlayer) }
        }
        Section("Real Player Stats") {
            stat("Player ID",0,0...255); stat("Shirt",1,0...30)
            Picker("Position", selection: Binding(get:{Int(bytes[2])},set:{bytes[2]=UInt8($0)})) { Text("FW").tag(0); Text("MF").tag(1); Text("DF").tag(2); Text("GK").tag(3) }
            stat("Level",4,0...255)
            Stepper("Stamina: \(Int(bytes[5])*2)", value: Binding(get:{Int(bytes[5])},set:{bytes[5]=UInt8(clamping:$0)}), in:0...255)
            stat("Mobility",6,0...255); stat("Attack",7,0...255); stat("Technique",8,0...255); stat("Judgment",9,0...255); stat("Spirit",10,0...255)
        }
        Section("TEAMDAT raw 16 bytes") { ForEach(0..<16,id:\.self) { i in stat(String(format:"B%02d",i),i,0...255) } }
        Button("💾 حفظ تعديل اللاعب") { model.savePlayer(model.selectedPlayer, bytes:bytes) }.disabled(model.teamData.isEmpty)
    }.navigationTitle("Player Editor") }.onAppear { bytes=model.playerRecord(model.selectedPlayer) }.onChange(of:model.selectedPlayer){_,_ in bytes=model.playerRecord(model.selectedPlayer)} }
    @ViewBuilder func stat(_ name:String,_ i:Int,_ range:ClosedRange<Int>)->some View { Stepper("\(name): \(bytes[i])", value:Binding(get:{Int(bytes[i])},set:{bytes[i]=UInt8(clamping:$0)}), in:range) }
}

struct ShotEditorView: View {
    @EnvironmentObject var model: CTJModel
    @State private var source: ShotRecord?
    @State private var target: ShotRecord?
    @State private var mode: ShotMode = .copy
    var unique:[ShotRecord] { var seen=Set<String>(); return model.shots.sorted{$0.offset<$1.offset}.filter { seen.insert("\($0.playerID)-\($0.shotSlot)").inserted } }
    var body: some View { NavigationStack { VStack {
        if model.captinData.isEmpty { ContentUnavailableView("استورد CAPTIN.EXE أولاً", systemImage:"doc.badge.plus") }
        else { List {
            Section("العملية") { Picker("Mode",selection:$mode){ForEach(ShotMode.allCases,id:\.self){Text($0.title).tag($0)}}
                Text("Source: \(desc(source))"); Text("Target: \(desc(target))")
                Button("تطبيق العملية") { if let s=source, let t=target { model.patchShot(source:s,target:t,mode:mode) } }.disabled(source==nil || target==nil)
            }
            Section("التسديدات — اضغط S للمصدر أو T للهدف") { ForEach(unique) { r in HStack {
                VStack(alignment:.leading) { Text(String(format:"ID %02X • Shot %02X",r.playerID,r.shotSlot)).font(.headline); Text(String(format:"Offset 0x%05X",r.offset)).font(.caption).foregroundStyle(.secondary) }
                Spacer(); Button("S"){source=r}.buttonStyle(.bordered); Button("T"){target=r}.buttonStyle(.borderedProminent)
            } } }
        } }
    }.navigationTitle("Shot ID Editor v42") } }
    func desc(_ r:ShotRecord?)->String { guard let r else{return "—"}; return String(format:"ID %02X / slot %02X @ 0x%05X",r.playerID,r.shotSlot,r.offset) }
}

struct TeamLogosView: View {
    let columns=[GridItem(.adaptive(minimum:82),spacing:12)]
    var body: some View { NavigationStack { ScrollView { LazyVGrid(columns:columns,spacing:16) { ForEach(0..<0x2D,id:\.self) { i in VStack { Image(String(format:"%02X",i)).interpolation(.none).resizable().scaledToFit().frame(width:72,height:60).background(.black.opacity(0.3)).clipShape(RoundedRectangle(cornerRadius:10)); Text("TEAM \(String(format:"%02X",i))").font(.caption.bold()) } } }.padding() }.navigationTitle("Team Logos 00–2C") } }
}
